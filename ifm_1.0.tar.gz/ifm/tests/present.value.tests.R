test.examples <- function()
{
  checkEquals(6, 6)
  checkEqualsNumeric(6, 6)
  checkIdentical(6, 6)
  checkTrue(2 + 2 == 4, 'Arithmetic works')
}