library('RUnit')

setwd("~/mestrado/ifm/ifm/R")

source('present.value.R')

test.suite <- defineTestSuite("imf",
                              dirs = file.path("."),
                              testFileRegexp = '^test.R')

test.result <- runTestSuite(test.suite)

printTextProtocol(test.result)
